import React, { useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Dimensions } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import PressableScale from './PressableScale';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows } from '../constants/theme';

const { width } = Dimensions.get('window');
const CARD_WIDTH = width * 0.7;
const CARD_SPACING = Spacing.md;

const StoreHighlightCard = ({ store, onPress }) => {
  return (
    <PressableScale onPress={() => onPress(store)} style={styles.card}>
      <View style={styles.cardContent}>
        <Image
          source={{ uri: store.image }}
          style={styles.cardImage}
          resizeMode="cover"
        />
        
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.9)']}
          style={styles.cardGradient}
        />

        <View style={styles.cardOverlay}>
          {store.discount && (
            <View style={styles.discountBadge}>
              <LinearGradient
                colors={Colors.gradientSunset}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.discountGradient}
              >
                <Ionicons name="pricetag" size={12} color={Colors.textLight} />
                <Text style={styles.discountText}>{store.discount}</Text>
              </LinearGradient>
            </View>
          )}

          <View style={styles.cardInfo}>
            <Text style={styles.cardTitle} numberOfLines={1}>
              {store.name}
            </Text>
            
            <View style={styles.cardMeta}>
              <View style={styles.ratingContainer}>
                <Ionicons name="star" size={14} color={Colors.rating} />
                <Text style={styles.ratingText}>{store.rating.toFixed(1)}</Text>
              </View>

              {store.deliveryTime && (
                <>
                  <View style={styles.metaDivider} />
                  <View style={styles.metaItem}>
                    <Ionicons name="time-outline" size={14} color={Colors.textLight} />
                    <Text style={styles.metaText}>{store.deliveryTime} min</Text>
                  </View>
                </>
              )}

              {store.distance && (
                <>
                  <View style={styles.metaDivider} />
                  <View style={styles.metaItem}>
                    <Ionicons name="location-outline" size={14} color={Colors.textLight} />
                    <Text style={styles.metaText}>{store.distance} km</Text>
                  </View>
                </>
              )}
            </View>

            {store.tags && store.tags.length > 0 && (
              <View style={styles.tagsContainer}>
                {store.tags.slice(0, 3).map((tag, index) => (
                  <View key={index} style={styles.tag}>
                    <Text style={styles.tagText}>{tag}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        </View>
      </View>
    </PressableScale>
  );
};

const HorizontalStoreHighlights = ({ title, subtitle, stores, onStorePress, onSeeAll }) => {
  const scrollViewRef = useRef(null);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.title}>{title}</Text>
          {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
        </View>
        
        {onSeeAll && (
          <TouchableOpacity 
            style={styles.seeAllButton} 
            onPress={onSeeAll}
            activeOpacity={0.7}
          >
            <Text style={styles.seeAllText}>Ver todos</Text>
            <Ionicons name="chevron-forward" size={16} color={Colors.primary} />
          </TouchableOpacity>
        )}
      </View>

      <ScrollView
        ref={scrollViewRef}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        snapToInterval={CARD_WIDTH + CARD_SPACING}
        decelerationRate="fast"
        bounces={false}
      >
        {stores.map((store, index) => (
          <View
            key={store.id}
            style={[
              styles.cardWrapper,
              index === 0 && styles.firstCard,
              index === stores.length - 1 && styles.lastCard,
            ]}
          >
            <StoreHighlightCard store={store} onPress={onStorePress} />
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  headerLeft: {
    flex: 1,
  },
  title: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  subtitle: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
  },
  seeAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.primaryLight,
  },
  seeAllText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
    marginRight: 4,
  },
  scrollContent: {
    paddingRight: Spacing.lg,
  },
  cardWrapper: {
    marginRight: CARD_SPACING,
  },
  firstCard: {
    marginLeft: Spacing.lg,
  },
  lastCard: {
    marginRight: Spacing.lg,
  },
  card: {
    width: CARD_WIDTH,
  },
  cardContent: {
    height: 220,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    backgroundColor: Colors.backgroundCard,
    ...Shadows.large,
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  cardGradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: '70%',
  },
  cardOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    top: 0,
    justifyContent: 'space-between',
    padding: Spacing.lg,
  },
  discountBadge: {
    alignSelf: 'flex-start',
  },
  discountGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.round,
    gap: 4,
    ...Shadows.colored,
  },
  discountText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  cardInfo: {
    gap: Spacing.xs,
  },
  cardTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
    marginBottom: 4,
  },
  cardMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
  },
  metaDivider: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.textLight + '60',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.medium,
    color: Colors.textLight,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.xs,
  },
  tag: {
    backgroundColor: Colors.glass.white,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
  },
  tagText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: Colors.textPrimary,
  },
});

export default HorizontalStoreHighlights;
