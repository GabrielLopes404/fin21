import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function StepCard({ number, icon, title, description, isLast }) {
  return (
    <View style={styles.stepContainer}>
      <View style={styles.stepIndicator}>
        <View style={styles.stepNumber}>
          <Text style={styles.stepNumberText}>{number}</Text>
        </View>
        {!isLast && <View style={styles.connector} />}
      </View>
      
      <View style={styles.stepCard}>
        <View style={styles.stepIconContainer}>
          <Ionicons name={icon} size={32} color={Colors.primary} />
        </View>
        <View style={styles.stepContent}>
          <Text style={styles.stepTitle}>{title}</Text>
          <Text style={styles.stepDescription}>{description}</Text>
        </View>
      </View>
    </View>
  );
}

export default function HowItWorksSection() {
  const steps = [
    {
      icon: 'search',
      title: 'Busque o que precisa',
      description: 'Encontre produtos, serviços e lojas próximas a você'
    },
    {
      icon: 'cart',
      title: 'Adicione ao carrinho',
      description: 'Escolha os melhores itens para seu pet'
    },
    {
      icon: 'card',
      title: 'Pague com segurança',
      description: 'Use cartão, PIX ou dinheiro na entrega'
    },
    {
      icon: 'checkmark-circle',
      title: 'Pronto!',
      description: 'Receba em casa ou agende o serviço'
    }
  ];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Como funciona?</Text>
      <Text style={styles.subtitle}>Simples, rápido e fácil</Text>
      
      <View style={styles.stepsContainer}>
        {steps.map((step, index) => (
          <StepCard
            key={index}
            number={index + 1}
            icon={step.icon}
            title={step.title}
            description={step.description}
            isLast={index === steps.length - 1}
          />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
    backgroundColor: Colors.backgroundLight,
    paddingVertical: Spacing.xxxl,
    paddingHorizontal: Spacing.lg,
  },
  title: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: Spacing.xs,
  },
  subtitle: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginBottom: Spacing.xxxl,
  },
  stepsContainer: {
    gap: 0,
  },
  stepContainer: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  stepIndicator: {
    alignItems: 'center',
    gap: 0,
  },
  stepNumber: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    ...Shadows.medium,
  },
  stepNumberText: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  connector: {
    width: 2,
    flex: 1,
    backgroundColor: Colors.primary + '30',
    marginVertical: Spacing.xs,
  },
  stepCard: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: Colors.background,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.lg,
    gap: Spacing.md,
    ...Shadows.small,
  },
  stepIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.primary + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepContent: {
    flex: 1,
    justifyContent: 'center',
  },
  stepTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: 4,
  },
  stepDescription: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    lineHeight: 18,
  },
});
