import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withDelay,
  withSequence,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Motion } from '../constants/theme';
import { useResponsiveLayout } from '../hooks/useResponsiveLayout';

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export default function CategoryGridPremium({ categories = [], onCategoryPress }) {
  const { getGridColumns, getCardWidth, spacing, isXS } = useResponsiveLayout();

  const columns = getGridColumns({ xs: 2, sm: 2, md: 3, lg: 4 });
  const gap = spacing.md;

  return (
    <View style={[styles.container, { gap }]}>
      <View style={[styles.grid, { gap }]}>
        {categories.map((category, index) => (
          <CategoryCard
            key={category.id}
            category={category}
            width={getCardWidth(columns, gap)}
            index={index}
            onPress={() => onCategoryPress?.(category)}
          />
        ))}
      </View>
    </View>
  );
}

function CategoryCard({ category, width, index, onPress }) {
  const scale = useSharedValue(0.8);
  const opacity = useSharedValue(0);
  const translateY = useSharedValue(20);
  const pressScale = useSharedValue(1);

  useEffect(() => {
    const delay = index * 50;
    
    scale.value = withDelay(delay, withSpring(1, Motion.spring.gentle));
    opacity.value = withDelay(delay, withSpring(1, Motion.spring.smooth));
    translateY.value = withDelay(delay, withSpring(0, Motion.spring.gentle));
  }, [index]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: scale.value * pressScale.value },
      { translateY: translateY.value },
    ],
    opacity: opacity.value,
  }));

  const handlePressIn = () => {
    pressScale.value = withSpring(0.95, Motion.spring.snappy);
  };

  const handlePressOut = () => {
    pressScale.value = withSequence(
      withSpring(1.03, Motion.spring.bouncy),
      withSpring(1, Motion.spring.gentle)
    );
  };

  const gradientColors = category.gradient || [category.color + 'DD', category.color];

  return (
    <AnimatedTouchable
      style={[styles.card, { width }, animatedStyle]}
      activeOpacity={0.9}
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
    >
      <LinearGradient
        colors={gradientColors}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.cardGradient}
      >
        <View style={styles.iconContainer}>
          <Ionicons 
            name={category.icon} 
            size={32} 
            color={Colors.textLight} 
          />
        </View>
        
        <Text style={styles.categoryName} numberOfLines={2}>
          {category.name}
        </Text>
        
        {category.count && (
          <Text style={styles.categoryCount}>
            {category.count}
          </Text>
        )}
      </LinearGradient>
    </AnimatedTouchable>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  card: {
    aspectRatio: 1,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    ...Shadows.medium,
  },
  cardGradient: {
    flex: 1,
    padding: Spacing.md,
    justifyContent: 'space-between',
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.md,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.sm,
  },
  categoryName: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
    lineHeight: 20,
  },
  categoryCount: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: 'rgba(255, 255, 255, 0.8)',
  },
});
