import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, Dimensions, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
  runOnJS,
} from 'react-native-reanimated';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows } from '../constants/theme';

const { width } = Dimensions.get('window');
const TOAST_WIDTH = width - Spacing.lg * 2;

const TOAST_TYPES = {
  success: {
    icon: 'checkmark-circle',
    colors: [Colors.success, Colors.successDark],
    iconColor: Colors.textLight,
  },
  error: {
    icon: 'close-circle',
    colors: [Colors.error, Colors.errorDark],
    iconColor: Colors.textLight,
  },
  warning: {
    icon: 'warning',
    colors: [Colors.warning, Colors.warningDark],
    iconColor: Colors.textLight,
  },
  info: {
    icon: 'information-circle',
    colors: Colors.gradientTwilight,
    iconColor: Colors.textLight,
  },
};

let toastQueue = [];
let showToastCallback = null;

export const showToast = (message, type = 'info', duration = 3000) => {
  toastQueue.push({ message, type, duration });
  if (showToastCallback) {
    showToastCallback();
  }
};

const ToastManager = () => {
  const [currentToast, setCurrentToast] = useState(null);
  const translateY = useSharedValue(-200);
  const opacity = useSharedValue(0);

  const processQueue = useCallback(() => {
    if (toastQueue.length > 0 && !currentToast) {
      const toast = toastQueue.shift();
      setCurrentToast(toast);
    }
  }, [currentToast]);

  useEffect(() => {
    showToastCallback = processQueue;
    return () => {
      showToastCallback = null;
    };
  }, [processQueue]);

  useEffect(() => {
    if (currentToast) {
      translateY.value = withSpring(0, {
        damping: 15,
        stiffness: 150,
      });
      opacity.value = withTiming(1, { duration: 300 });

      const timer = setTimeout(() => {
        hideToast();
      }, currentToast.duration);

      return () => clearTimeout(timer);
    }
  }, [currentToast]);

  const hideToast = () => {
    translateY.value = withSpring(-200, {
      damping: 15,
      stiffness: 150,
    });
    opacity.value = withTiming(0, { duration: 200 }, (finished) => {
      if (finished) {
        runOnJS(setCurrentToast)(null);
        runOnJS(processQueue)();
      }
    });
  };

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ translateY: translateY.value }],
      opacity: opacity.value,
    };
  });

  if (!currentToast) return null;

  const toastConfig = TOAST_TYPES[currentToast.type] || TOAST_TYPES.info;

  return (
    <Animated.View style={[styles.container, animatedStyle]}>
      <LinearGradient
        colors={toastConfig.colors}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.toast}
      >
        <View style={styles.iconContainer}>
          <Ionicons 
            name={toastConfig.icon} 
            size={24} 
            color={toastConfig.iconColor} 
          />
        </View>
        
        <Text style={styles.message} numberOfLines={2}>
          {currentToast.message}
        </Text>
      </LinearGradient>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 60 : 40,
    left: Spacing.lg,
    right: Spacing.lg,
    zIndex: 9999,
  },
  toast: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    borderRadius: BorderRadius.lg,
    ...Shadows.large,
  },
  iconContainer: {
    marginRight: Spacing.md,
  },
  message: {
    flex: 1,
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textLight,
    lineHeight: FontSizes.md * 1.4,
  },
});

export default ToastManager;
