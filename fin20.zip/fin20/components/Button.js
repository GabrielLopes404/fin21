import React from 'react';
import { Text, StyleSheet, ActivityIndicator } from 'react-native';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue, 
  withSpring,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import PressableScale from './PressableScale';
import { Colors, FontSizes, BorderRadius, Spacing, FontWeights, Shadows } from '../constants/theme';

export default function Button({ 
  title, 
  onPress, 
  variant = 'primary',
  size = 'large',
  loading = false,
  disabled = false,
  icon = null,
  style,
  fullWidth = true,
}) {
  const shimmer = useSharedValue(0);

  // Design Profissional - Cores Sólidas
  const getBackgroundColor = () => {
    if (disabled) return Colors.backgroundGray;
    switch (variant) {
      case 'primary': return Colors.primary;        // Navy
      case 'accent': return Colors.accent;          // Dourado
      case 'success': return Colors.success;        // Verde profissional
      case 'secondary': return Colors.backgroundGray;
      case 'outline': return 'transparent';
      default: return Colors.primary;
    }
  };

  const getTextColor = () => {
    if (variant === 'secondary') return Colors.textPrimary;
    if (variant === 'outline') return Colors.primary;
    if (disabled) return Colors.textMuted;
    return Colors.textLight;
  };

  const getBorderColor = () => {
    if (variant === 'outline') return Colors.primary;
    return 'transparent';
  };

  const getHeight = () => {
    switch (size) {
      case 'small': return 44;
      case 'medium': return 50;
      case 'large': return 56;
      default: return 56;
    }
  };

  const getFontSize = () => {
    switch (size) {
      case 'small': return FontSizes.sm;
      case 'medium': return FontSizes.md;
      case 'large': return FontSizes.md;
      default: return FontSizes.md;
    }
  };

  const handlePress = () => {
    shimmer.value = withSequence(
      withTiming(1, { duration: 150 }),
      withTiming(0, { duration: 150 })
    );
    onPress && onPress();
  };

  // Design Profissional - Sem Gradientes
  return (
    <PressableScale
      onPress={handlePress}
      disabled={disabled || loading}
      style={[
        styles.button,
        {
          height: getHeight(),
          backgroundColor: getBackgroundColor(),
          borderWidth: variant === 'outline' ? 1.5 : 0,
          borderColor: getBorderColor(),
          width: fullWidth ? '100%' : 'auto',
        },
        disabled && styles.disabled,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={getTextColor()} size="small" />
      ) : (
        <>
          {icon}
          <Text style={[styles.text, { color: getTextColor(), fontSize: getFontSize() }]}>
            {title}
          </Text>
        </>
      )}
    </PressableScale>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: BorderRadius.md,      // Mais corporativo (10px)
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.xxl,
    gap: Spacing.sm,
    ...Shadows.small,                   // Sombra mais sutil
  },
  text: {
    fontWeight: FontWeights.semibold,   // Peso mais moderado
    letterSpacing: 0.3,                 // Letra spacing mais profissional
  },
  disabled: {
    opacity: 0.4,
  },
});
