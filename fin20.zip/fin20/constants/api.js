const API_BASE_URL = typeof window !== 'undefined' && window.location 
  ? `${window.location.protocol}//${window.location.host}`
  : 'http://localhost:3001';

export const API_CONFIG = {
  BASE_URL: API_BASE_URL,
  TIMEOUT: 10000,
  ENDPOINTS: {
    AUTH: {
      LOGIN: '/api/auth/login',
      SIGNUP: '/api/auth/signup',
      FORGOT_PASSWORD: '/api/auth/forgot-password',
      RESET_PASSWORD: '/api/auth/reset-password',
    },
    STORES: {
      LIST: '/api/stores',
      DETAIL: (id) => `/api/stores/${id}`,
      SEARCH: '/api/stores/search',
    },
    PRODUCTS: {
      LIST: '/api/products',
      DETAIL: (id) => `/api/products/${id}`,
      BY_STORE: (storeId) => `/api/products/store/${storeId}`,
    },
    SERVICES: {
      LIST: '/api/services',
      DETAIL: (id) => `/api/services/${id}`,
      BY_STORE: (storeId) => `/api/services/store/${storeId}`,
    },
    CART: {
      GET: '/api/cart',
      ADD: '/api/cart',
      UPDATE: (itemId) => `/api/cart/${itemId}`,
      DELETE: (itemId) => `/api/cart/${itemId}`,
      CLEAR: '/api/cart/clear',
    },
    ORDERS: {
      LIST: '/api/orders',
      DETAIL: (id) => `/api/orders/${id}`,
      CREATE: '/api/orders',
    },
    FAVORITES: {
      LIST: '/api/favorites',
      ADD: '/api/favorites',
      REMOVE: (storeId) => `/api/favorites/${storeId}`,
    },
    ADDRESSES: {
      LIST: '/api/addresses',
      CREATE: '/api/addresses',
      UPDATE: (id) => `/api/addresses/${id}`,
      DELETE: (id) => `/api/addresses/${id}`,
    },
    PROFILE: {
      GET: '/api/profile',
      UPDATE: '/api/profile',
    },
    NOTIFICATIONS: {
      LIST: '/api/notifications',
      MARK_READ: (id) => `/api/notifications/${id}/read`,
    },
    BOOKINGS: {
      LIST: '/api/bookings',
      CREATE: '/api/bookings',
      DETAIL: (id) => `/api/bookings/${id}`,
    },
    COUPONS: {
      VALIDATE: '/api/coupons/validate',
    },
  },
};

export default API_CONFIG;
