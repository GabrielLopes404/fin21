import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius } from '../constants/theme';
import SearchBarPremium from '../components/SearchBarPremium';
import StoreListItem from '../components/StoreListItem';
import CategoryIconRow from '../components/CategoryIconRow';
import { stores, categories } from '../constants/mockData';

export default function SearchScreen() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredStores, setFilteredStores] = useState([]);
  const [recentSearches, setRecentSearches] = useState([
    'Banho e tosa',
    'Ração premium',
    'Veterinário',
    'Pet shop',
  ]);

  useEffect(() => {
    if (searchQuery.trim()) {
      const filtered = stores.filter(store =>
        store.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        store.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
      setFilteredStores(filtered);
    } else {
      setFilteredStores([]);
    }
  }, [searchQuery]);

  const handleSearch = (query) => {
    setSearchQuery(query);
    if (query.trim() && !recentSearches.includes(query)) {
      setRecentSearches(prev => [query, ...prev.slice(0, 4)]);
    }
  };

  const handleCategoryPress = (category) => {
    setSearchQuery(category.name);
  };

  const handleStorePress = (store) => {
    router.push(`/store/${store.id}`);
  };

  const handleRecentSearchPress = (search) => {
    setSearchQuery(search);
  };

  const clearRecentSearch = (search) => {
    setRecentSearches(prev => prev.filter(s => s !== search));
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <View style={styles.searchContainer}>
          <SearchBarPremium
            onSearch={handleSearch}
            placeholder="Buscar lojas, produtos, serviços..."
          />
        </View>
      </View>

      {!searchQuery.trim() ? (
        <View style={styles.content}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Categorias</Text>
            <CategoryIconRow
              categories={categories}
              onCategoryPress={handleCategoryPress}
            />
          </View>

          {recentSearches.length > 0 && (
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Buscas recentes</Text>
                <TouchableOpacity onPress={() => setRecentSearches([])}>
                  <Text style={styles.clearButton}>Limpar</Text>
                </TouchableOpacity>
              </View>
              
              {recentSearches.map((search, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.recentItem}
                  onPress={() => handleRecentSearchPress(search)}
                  activeOpacity={0.7}
                >
                  <View style={styles.recentItemLeft}>
                    <Ionicons name="time-outline" size={20} color={Colors.textSecondary} />
                    <Text style={styles.recentText}>{search}</Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => clearRecentSearch(search)}
                    style={styles.removeButton}
                  >
                    <Ionicons name="close" size={18} color={Colors.textSecondary} />
                  </TouchableOpacity>
                </TouchableOpacity>
              ))}
            </View>
          )}

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Lojas populares</Text>
            <FlatList
              data={stores.slice(0, 5)}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <StoreListItem store={item} onPress={handleStorePress} />
              )}
              scrollEnabled={false}
            />
          </View>
        </View>
      ) : (
        <View style={styles.resultsContainer}>
          {filteredStores.length > 0 ? (
            <>
              <Text style={styles.resultsTitle}>
                {filteredStores.length} resultado{filteredStores.length !== 1 ? 's' : ''} encontrado{filteredStores.length !== 1 ? 's' : ''}
              </Text>
              <FlatList
                data={filteredStores}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <StoreListItem store={item} onPress={handleStorePress} />
                )}
                contentContainerStyle={styles.resultsList}
              />
            </>
          ) : (
            <View style={styles.emptyState}>
              <Ionicons name="search-outline" size={80} color={Colors.textSecondary} />
              <Text style={styles.emptyTitle}>Nenhum resultado encontrado</Text>
              <Text style={styles.emptySubtitle}>
                Tente buscar por outro termo
              </Text>
            </View>
          )}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    gap: Spacing.sm,
  },
  backButton: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchContainer: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  section: {
    marginTop: Spacing.xl,
    marginBottom: Spacing.lg,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  sectionTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.sm,
  },
  clearButton: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
  },
  recentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.backgroundLight,
    marginHorizontal: Spacing.lg,
    marginBottom: Spacing.xs,
    borderRadius: BorderRadius.md,
  },
  recentItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    flex: 1,
  },
  recentText: {
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
    flex: 1,
  },
  removeButton: {
    padding: Spacing.xs,
  },
  resultsContainer: {
    flex: 1,
  },
  resultsTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textSecondary,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
  },
  resultsList: {
    paddingBottom: Spacing.xxxl,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xxxl * 2,
  },
  emptyTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginTop: Spacing.xl,
    marginBottom: Spacing.sm,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    textAlign: 'center',
  },
});
