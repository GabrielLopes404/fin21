import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function HelpCategory({ icon, title, description, onPress }) {
  return (
    <TouchableOpacity
      style={styles.categoryCard}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={styles.categoryIcon}>
        <Ionicons name={icon} size={28} color={Colors.primary} />
      </View>
      <View style={styles.categoryContent}>
        <Text style={styles.categoryTitle}>{title}</Text>
        <Text style={styles.categoryDescription}>{description}</Text>
      </View>
      <Ionicons name="chevron-forward" size={24} color={Colors.textSecondary} />
    </TouchableOpacity>
  );
}

function QuickAction({ icon, title, onPress }) {
  return (
    <TouchableOpacity
      style={styles.quickAction}
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={styles.quickActionIcon}>
        <Ionicons name={icon} size={24} color={Colors.primary} />
      </View>
      <Text style={styles.quickActionTitle}>{title}</Text>
    </TouchableOpacity>
  );
}

export default function HelpCenterScreen() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');

  const categories = [
    {
      id: '1',
      icon: 'cart-outline',
      title: 'Pedidos e Entregas',
      description: 'Rastreamento, status e problemas com pedidos',
    },
    {
      id: '2',
      icon: 'card-outline',
      title: 'Pagamentos',
      description: 'Formas de pagamento, reembolsos e cobranças',
    },
    {
      id: '3',
      icon: 'calendar-outline',
      title: 'Agendamentos',
      description: 'Agendar, cancelar ou reagendar serviços',
    },
    {
      id: '4',
      icon: 'person-outline',
      title: 'Minha Conta',
      description: 'Dados pessoais, senha e configurações',
    },
    {
      id: '5',
      icon: 'pricetag-outline',
      title: 'Promoções e Cupons',
      description: 'Descontos, cupons e programa de fidelidade',
    },
    {
      id: '6',
      icon: 'shield-checkmark-outline',
      title: 'Segurança',
      description: 'Privacidade, dados e proteção da conta',
    },
  ];

  const handleCategoryPress = (category) => {
    console.log('Category pressed:', category);
  };

  const handleChatPress = () => {
    console.log('Open chat');
  };

  const handleCallPress = () => {
    console.log('Call support');
  };

  const handleEmailPress = () => {
    console.log('Send email');
  };

  const handleWhatsAppPress = () => {
    console.log('Open WhatsApp');
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Central de Ajuda</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.searchContainer}>
          <Ionicons name="search" size={20} color={Colors.textSecondary} style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Como podemos ajudar?"
            placeholderTextColor={Colors.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        <Text style={styles.sectionTitle}>Fale conosco</Text>
        <View style={styles.quickActions}>
          <QuickAction
            icon="chatbubbles"
            title="Chat"
            onPress={handleChatPress}
          />
          <QuickAction
            icon="call"
            title="Ligar"
            onPress={handleCallPress}
          />
          <QuickAction
            icon="mail"
            title="E-mail"
            onPress={handleEmailPress}
          />
          <QuickAction
            icon="logo-whatsapp"
            title="WhatsApp"
            onPress={handleWhatsAppPress}
          />
        </View>

        <Text style={styles.sectionTitle}>Categorias de Ajuda</Text>
        {categories.map((category) => (
          <HelpCategory
            key={category.id}
            {...category}
            onPress={() => handleCategoryPress(category)}
          />
        ))}

        <View style={styles.contactInfo}>
          <Text style={styles.contactTitle}>Horário de atendimento</Text>
          <Text style={styles.contactText}>Segunda a Sexta: 8h - 20h</Text>
          <Text style={styles.contactText}>Sábado: 9h - 18h</Text>
          <Text style={styles.contactText}>Domingo: 9h - 14h</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    padding: Spacing.sm,
  },
  headerTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    flex: 1,
    marginLeft: Spacing.md,
  },
  placeholder: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    marginBottom: Spacing.xl,
    ...Shadows.small,
  },
  searchIcon: {
    marginRight: Spacing.md,
  },
  searchInput: {
    flex: 1,
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
  },
  sectionTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  quickActions: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginBottom: Spacing.xl,
  },
  quickAction: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.md,
    padding: Spacing.lg,
    ...Shadows.small,
  },
  quickActionIcon: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.primary + '15',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.sm,
  },
  quickActionTitle: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  categoryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.md,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
    ...Shadows.small,
  },
  categoryIcon: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.primary + '10',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  categoryContent: {
    flex: 1,
  },
  categoryTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  categoryDescription: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    lineHeight: 18,
  },
  contactInfo: {
    backgroundColor: Colors.primary + '10',
    borderRadius: BorderRadius.md,
    padding: Spacing.lg,
    marginTop: Spacing.lg,
  },
  contactTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.bold,
    color: Colors.primary,
    marginBottom: Spacing.sm,
  },
  contactText: {
    fontSize: FontSizes.sm,
    color: Colors.primary,
    marginBottom: Spacing.xs,
  },
});
