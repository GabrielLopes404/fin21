import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius, Shadows } from '../constants/theme';

function OptionItem({ icon, title, description, onPress, showChevron = true, rightElement }) {
  return (
    <TouchableOpacity
      style={styles.optionItem}
      onPress={onPress}
      activeOpacity={0.8}
      disabled={!onPress}
    >
      <View style={styles.optionLeft}>
        <View style={styles.optionIcon}>
          <Ionicons name={icon} size={24} color={Colors.primary} />
        </View>
        <View style={styles.optionText}>
          <Text style={styles.optionTitle}>{title}</Text>
          {description && <Text style={styles.optionDescription}>{description}</Text>}
        </View>
      </View>
      {rightElement || (showChevron && (
        <Ionicons name="chevron-forward" size={20} color={Colors.textSecondary} />
      ))}
    </TouchableOpacity>
  );
}

export default function PrivacySecurityScreen() {
  const router = useRouter();
  const [biometricEnabled, setBiometricEnabled] = useState(true);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Privacidade e segurança</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.sectionTitle}>Segurança da conta</Text>
        <View style={styles.card}>
          <OptionItem
            icon="key-outline"
            title="Alterar senha"
            description="Última alteração: 30 dias atrás"
            onPress={() => console.log('Change password')}
          />
          <View style={styles.divider} />
          <OptionItem
            icon="finger-print-outline"
            title="Biometria"
            description="Login com digital ou Face ID"
            showChevron={false}
            rightElement={
              <Switch
                value={biometricEnabled}
                onValueChange={setBiometricEnabled}
                trackColor={{ false: Colors.border, true: Colors.primary + '50' }}
                thumbColor={biometricEnabled ? Colors.primary : Colors.backgroundLight}
              />
            }
          />
          <View style={styles.divider} />
          <OptionItem
            icon="shield-checkmark-outline"
            title="Autenticação em duas etapas"
            description="Proteção extra para sua conta"
            showChevron={false}
            rightElement={
              <Switch
                value={twoFactorEnabled}
                onValueChange={setTwoFactorEnabled}
                trackColor={{ false: Colors.border, true: Colors.primary + '50' }}
                thumbColor={twoFactorEnabled ? Colors.primary : Colors.backgroundLight}
              />
            }
          />
        </View>

        <Text style={styles.sectionTitle}>Privacidade</Text>
        <View style={styles.card}>
          <OptionItem
            icon="eye-outline"
            title="Controle de privacidade"
            description="Gerencie quem pode ver suas informações"
            onPress={() => console.log('Privacy controls')}
          />
          <View style={styles.divider} />
          <OptionItem
            icon="location-outline"
            title="Localização"
            description="Permissões de localização do app"
            onPress={() => console.log('Location settings')}
          />
          <View style={styles.divider} />
          <OptionItem
            icon="analytics-outline"
            title="Compartilhamento de dados"
            description="Dados coletados e compartilhados"
            onPress={() => console.log('Data sharing')}
          />
        </View>

        <Text style={styles.sectionTitle}>Dados</Text>
        <View style={styles.card}>
          <OptionItem
            icon="download-outline"
            title="Baixar meus dados"
            description="Exportar uma cópia dos seus dados"
            onPress={() => console.log('Download data')}
          />
          <View style={styles.divider} />
          <OptionItem
            icon="trash-outline"
            title="Excluir conta"
            description="Remover permanentemente sua conta"
            onPress={() => console.log('Delete account')}
          />
        </View>

        <Text style={styles.sectionTitle}>Sessões ativas</Text>
        <View style={styles.card}>
          <View style={styles.sessionItem}>
            <View style={styles.sessionIcon}>
              <Ionicons name="phone-portrait" size={24} color={Colors.primary} />
            </View>
            <View style={styles.sessionInfo}>
              <Text style={styles.sessionDevice}>iPhone 13</Text>
              <Text style={styles.sessionDetails}>São Paulo, Brasil • Agora</Text>
            </View>
            <View style={styles.currentBadge}>
              <Text style={styles.currentText}>Atual</Text>
            </View>
          </View>
        </View>

        <View style={styles.infoBox}>
          <Ionicons name="shield-checkmark" size={24} color={Colors.success} />
          <View style={styles.infoContent}>
            <Text style={styles.infoTitle}>Sua conta está protegida</Text>
            <Text style={styles.infoText}>
              Usamos criptografia de ponta a ponta para proteger seus dados
            </Text>
          </View>
        </View>

        <TouchableOpacity style={styles.linkButton} activeOpacity={0.7}>
          <Text style={styles.linkText}>Política de Privacidade</Text>
          <Ionicons name="open-outline" size={16} color={Colors.primary} />
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    padding: Spacing.sm,
  },
  headerTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    flex: 1,
    marginLeft: Spacing.md,
  },
  placeholder: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
  },
  sectionTitle: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textSecondary,
    marginBottom: Spacing.md,
    marginTop: Spacing.lg,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  card: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
    ...Shadows.small,
  },
  optionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: Spacing.lg,
  },
  optionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: Spacing.md,
  },
  optionIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.primary + '10',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  optionText: {
    flex: 1,
  },
  optionTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  optionDescription: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginLeft: Spacing.lg + 48 + Spacing.md,
  },
  sessionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.lg,
  },
  sessionIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.primary + '10',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  sessionInfo: {
    flex: 1,
  },
  sessionDevice: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginBottom: 2,
  },
  sessionDetails: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
  },
  currentBadge: {
    backgroundColor: Colors.success + '20',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
  },
  currentText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
    color: Colors.success,
  },
  infoBox: {
    flexDirection: 'row',
    backgroundColor: Colors.success + '10',
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    marginTop: Spacing.xl,
    gap: Spacing.md,
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.success,
    marginBottom: Spacing.xs,
  },
  infoText: {
    fontSize: FontSizes.sm,
    color: Colors.success,
    lineHeight: 18,
  },
  linkButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    paddingVertical: Spacing.lg,
  },
  linkText: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.primary,
  },
});
