import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { Colors, FontSizes, Spacing, FontWeights, BorderRadius } from '../constants/theme';

export default function TermsScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Termos de Uso</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.intro}>
          <Text style={styles.lastUpdated}>Última atualização: 10 de novembro de 2025</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>1. Aceitação dos Termos</Text>
          <Text style={styles.paragraph}>
            Ao acessar e usar o aplicativo PetsGo, você aceita e concorda em cumprir estes termos e condições de uso. Se você não concordar com qualquer parte destes termos, não deverá usar nossos serviços.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>2. Uso do Serviço</Text>
          <Text style={styles.paragraph}>
            O PetsGo é uma plataforma que conecta donos de pets a lojas, produtos e serviços relacionados a animais de estimação. Você concorda em usar o serviço apenas para fins legais e de acordo com estes termos.
          </Text>
          <Text style={styles.subTitle}>Você concorda em NÃO:</Text>
          <Text style={styles.bulletPoint}>• Usar o serviço para qualquer propósito ilegal</Text>
          <Text style={styles.bulletPoint}>• Violar direitos de propriedade intelectual</Text>
          <Text style={styles.bulletPoint}>• Transmitir vírus ou códigos maliciosos</Text>
          <Text style={styles.bulletPoint}>• Fazer uso indevido de informações de outros usuários</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>3. Cadastro e Conta</Text>
          <Text style={styles.paragraph}>
            Para usar determinados recursos do PetsGo, você deve criar uma conta fornecendo informações precisas e completas. Você é responsável por manter a confidencialidade de sua senha e por todas as atividades que ocorrem em sua conta.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>4. Pedidos e Pagamentos</Text>
          <Text style={styles.paragraph}>
            Ao fazer um pedido através do PetsGo, você concorda em fornecer informações de pagamento válidas e autoriza a cobrança do valor total do pedido, incluindo taxas de entrega aplicáveis.
          </Text>
          <Text style={styles.paragraph}>
            Todos os preços estão sujeitos a alterações sem aviso prévio. Reservamo-nos o direito de modificar ou descontinuar produtos a qualquer momento.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>5. Cancelamentos e Reembolsos</Text>
          <Text style={styles.paragraph}>
            Você pode cancelar pedidos de acordo com nossa política de cancelamento. Reembolsos serão processados no prazo de 7 a 14 dias úteis, dependendo do método de pagamento.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>6. Propriedade Intelectual</Text>
          <Text style={styles.paragraph}>
            Todo o conteúdo do aplicativo PetsGo, incluindo textos, gráficos, logos, imagens e software, é propriedade do PetsGo ou de seus fornecedores de conteúdo e é protegido por leis de direitos autorais.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>7. Limitação de Responsabilidade</Text>
          <Text style={styles.paragraph}>
            O PetsGo não será responsável por quaisquer danos indiretos, incidentais, especiais ou consequenciais resultantes do uso ou da incapacidade de usar nossos serviços.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>8. Modificações dos Termos</Text>
          <Text style={styles.paragraph}>
            Reservamo-nos o direito de modificar estes termos a qualquer momento. As modificações entrarão em vigor imediatamente após sua publicação no aplicativo. O uso contínuo do serviço após as modificações constitui aceitação dos novos termos.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>9. Privacidade</Text>
          <Text style={styles.paragraph}>
            Seu uso do PetsGo também é regido por nossa Política de Privacidade. Recomendamos que você leia nossa política para entender como coletamos, usamos e protegemos suas informações.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>10. Contato</Text>
          <Text style={styles.paragraph}>
            Se você tiver dúvidas sobre estes Termos de Uso, entre em contato conosco:
          </Text>
          <Text style={styles.contactInfo}>Email: suporte@petsgo.com.br</Text>
          <Text style={styles.contactInfo}>Telefone: (11) 4000-0000</Text>
          <Text style={styles.contactInfo}>Endereço: Av. Paulista, 1000 - São Paulo, SP</Text>
        </View>

        <View style={styles.agreementBox}>
          <Ionicons name="checkmark-circle" size={24} color={Colors.success} />
          <Text style={styles.agreementText}>
            Ao usar o PetsGo, você concorda com estes termos de uso
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    backgroundColor: Colors.backgroundLight,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backButton: {
    padding: Spacing.sm,
  },
  headerTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    flex: 1,
    marginLeft: Spacing.md,
  },
  placeholder: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: Spacing.lg,
  },
  intro: {
    marginBottom: Spacing.xl,
  },
  lastUpdated: {
    fontSize: FontSizes.sm,
    color: Colors.textSecondary,
    fontStyle: 'italic',
  },
  section: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
  },
  subTitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
    marginTop: Spacing.md,
    marginBottom: Spacing.sm,
  },
  paragraph: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    lineHeight: 24,
    marginBottom: Spacing.md,
  },
  bulletPoint: {
    fontSize: FontSizes.md,
    color: Colors.textSecondary,
    lineHeight: 24,
    marginBottom: Spacing.xs,
  },
  contactInfo: {
    fontSize: FontSizes.md,
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  agreementBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.success + '10',
    borderRadius: BorderRadius.md,
    padding: Spacing.lg,
    marginTop: Spacing.lg,
    gap: Spacing.md,
  },
  agreementText: {
    flex: 1,
    fontSize: FontSizes.sm,
    color: Colors.success,
    lineHeight: 20,
    fontWeight: FontWeights.semibold,
  },
});
