const express = require('express');
const router = express.Router();
const db = require('../database/db');
const { authenticateToken } = require('../middleware/auth');

router.use(authenticateToken);

router.get('/', async (req, res) => {
  try {
    const userId = req.user.userId;

    const result = await db.query(
      `SELECT 
        ci.id,
        ci.quantity,
        p.id as product_id,
        p.name,
        p.price,
        p.original_price,
        p.image_url,
        s.id as store_id,
        s.name as store_name,
        s.delivery_fee
      FROM cart_items ci
      JOIN products p ON ci.product_id = p.id
      JOIN stores s ON p.store_id = s.id
      WHERE ci.user_id = $1
      ORDER BY ci.created_at DESC`,
      [userId]
    );

    const cartItems = result.rows;
    const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const deliveryFee = cartItems.length > 0 ? cartItems[0].delivery_fee : 0;
    const total = subtotal + deliveryFee;

    res.json({
      items: cartItems,
      summary: {
        subtotal,
        deliveryFee,
        total,
        itemCount: cartItems.reduce((sum, item) => sum + item.quantity, 0)
      }
    });
  } catch (error) {
    console.error('Error fetching cart:', error);
    res.status(500).json({ error: 'Erro ao buscar carrinho' });
  }
});

router.post('/items', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { product_id, quantity = 1 } = req.body;

    if (!product_id) {
      return res.status(400).json({ error: 'product_id é obrigatório' });
    }

    const result = await db.query(
      `INSERT INTO cart_items (user_id, product_id, quantity)
       VALUES ($1, $2, $3)
       ON CONFLICT (user_id, product_id)
       DO UPDATE SET quantity = cart_items.quantity + $3, updated_at = NOW()
       RETURNING *`,
      [userId, product_id, quantity]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error adding to cart:', error);
    res.status(500).json({ error: 'Erro ao adicionar ao carrinho' });
  }
});

router.patch('/items/:id', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { id } = req.params;
    const { quantity } = req.body;

    if (quantity < 1) {
      return res.status(400).json({ error: 'Quantidade deve ser pelo menos 1' });
    }

    const result = await db.query(
      `UPDATE cart_items 
       SET quantity = $1, updated_at = NOW()
       WHERE id = $2 AND user_id = $3
       RETURNING *`,
      [quantity, id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Item não encontrado no carrinho' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating cart item:', error);
    res.status(500).json({ error: 'Erro ao atualizar item' });
  }
});

router.delete('/items/:id', async (req, res) => {
  try {
    const userId = req.user.userId;
    const { id } = req.params;

    const result = await db.query(
      'DELETE FROM cart_items WHERE id = $1 AND user_id = $2 RETURNING *',
      [id, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Item não encontrado no carrinho' });
    }

    res.json({ message: 'Item removido do carrinho' });
  } catch (error) {
    console.error('Error removing from cart:', error);
    res.status(500).json({ error: 'Erro ao remover item' });
  }
});

router.delete('/', async (req, res) => {
  try {
    const userId = req.user.userId;

    await db.query('DELETE FROM cart_items WHERE user_id = $1', [userId]);

    res.json({ message: 'Carrinho esvaziado' });
  } catch (error) {
    console.error('Error clearing cart:', error);
    res.status(500).json({ error: 'Erro ao esvaziar carrinho' });
  }
});

module.exports = router;
