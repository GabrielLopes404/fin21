-- Script para popular o banco com dados iniciais
-- Execute após criar o schema

-- Inserir lojas de exemplo
INSERT INTO stores (name, description, image_url, latitude, longitude, address, phone, category, tags, rating, total_reviews, is_featured, delivery_fee, min_delivery_time, max_delivery_time) VALUES
('PetShop & Banho Premium', 'Loja completa com produtos e serviços para seu pet', 'https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=500', -23.550520, -46.633308, 'Rua Augusta, 1000 - São Paulo, SP', '(11) 3000-1000', 'PetShop', ARRAY['Banho', 'Tosa', 'Produtos'], 4.8, 150, true, 5.90, 30, 40),
('Clínica Veterinária Animal Care', 'Clínica completa com veterinários especializados', 'https://images.unsplash.com/photo-1628009368231-7bb7cfcb0def?w=500', -23.548520, -46.635308, 'Av. Paulista, 500 - São Paulo, SP', '(11) 3000-2000', 'Veterinária', ARRAY['Veterinário', 'Emergência', 'Vacinas'], 4.9, 200, true, 0, NULL, NULL),
('Pet Shop Boulevard', 'Especializada em rações e acessórios premium', 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=500', -23.560520, -46.643308, 'Rua Oscar Freire, 200 - São Paulo, SP', '(11) 3000-3000', 'PetShop', ARRAY['Ração', 'Brinquedos', 'Acessórios'], 4.7, 120, false, 8.90, 45, 60),
('Farmácia Pet & Cia', 'Medicamentos e suplementos para pets', 'https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=500', -23.565520, -46.650308, 'Rua Haddock Lobo, 300 - São Paulo, SP', '(11) 3000-4000', 'Farmácia', ARRAY['Medicamentos', 'Suplementos'], 4.6, 80, false, 12.90, 50, 70),
('Dog Walker & Pet Sitter', 'Passeios e hospedagem para seu pet', 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=500', -23.545520, -46.628308, 'Rua Estados Unidos, 100 - São Paulo, SP', '(11) 3000-5000', 'Serviços', ARRAY['Passeio', 'Pet Sitter', 'Day Care'], 5.0, 95, true, 0, NULL, NULL);

-- Buscar os IDs das lojas inseridas
DO $$
DECLARE
  store1_id UUID;
  store2_id UUID;
  store3_id UUID;
BEGIN
  SELECT id INTO store1_id FROM stores WHERE name = 'PetShop & Banho Premium' LIMIT 1;
  SELECT id INTO store2_id FROM stores WHERE name = 'Clínica Veterinária Animal Care' LIMIT 1;
  SELECT id INTO store3_id FROM stores WHERE name = 'Pet Shop Boulevard' LIMIT 1;

  -- Inserir produtos
  INSERT INTO products (store_id, name, description, price, original_price, image_url, category, brand, stock_quantity) VALUES
  (store1_id, 'Ração Premium Golden para Cães Adultos', 'Alimento completo e balanceado 15kg', 189.90, 229.90, 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=500', 'Ração', 'Golden', 50),
  (store1_id, 'Brinquedo Kong Classic', 'Brinquedo resistente para cães', 49.90, NULL, 'https://images.unsplash.com/photo-1535294435445-d7249524ef2e?w=500', 'Brinquedos', 'Kong', 30),
  (store3_id, 'Arranhador Torre para Gatos', 'Torre com 3 andares e brinquedos', 299.90, 399.90, 'https://images.unsplash.com/photo-1545249390-6bdfa286032f?w=500', 'Acessórios', 'PetFun', 15),
  (store3_id, 'Coleira Antipulgas Seresto', 'Proteção por até 8 meses', 159.90, NULL, 'https://images.unsplash.com/photo-1623387641168-d9803ddd3f35?w=500', 'Saúde', 'Seresto', 25);

  -- Inserir serviços
  INSERT INTO services (store_id, name, description, price, duration_minutes, category) VALUES
  (store1_id, 'Banho Completo', 'Banho, secagem e perfume', 60.00, 60, 'Banho & Tosa'),
  (store1_id, 'Tosa Higiênica', 'Tosa de áreas sensíveis', 45.00, 45, 'Banho & Tosa'),
  (store1_id, 'Tosa Completa', 'Banho + tosa completa', 120.00, 120, 'Banho & Tosa'),
  (store2_id, 'Consulta Veterinária', 'Consulta completa com veterinário', 200.00, 45, 'Veterinária'),
  (store2_id, 'Vacina V10', 'Vacinação completa V10', 150.00, 15, 'Vacinas'),
  (store2_id, 'Banho Medicamentoso', 'Banho com produtos medicinais', 80.00, 60, 'Tratamentos');

  -- Inserir cupons
  INSERT INTO coupons (code, description, discount_type, discount_value, min_purchase_amount, max_discount_amount, is_active) VALUES
  ('BEMVINDO', 'Cupom de boas-vindas: 20% de desconto na primeira compra', 'percentage', 20, 50, 50, true),
  ('FRETEGRATIS', 'Frete grátis em compras acima de R$ 150', 'fixed', 0, 150, NULL, true),
  ('PET10', '10% de desconto em qualquer compra', 'percentage', 10, 0, 30, true);

  -- Inserir banners
  INSERT INTO banners (title, subtitle, image_url, color, action, is_active, display_order) VALUES
  ('Primeira compra com 20% OFF', 'Use o cupom BEMVINDO no checkout', 'https://images.unsplash.com/photo-1450778869180-41d0601e046e?w=800', '#4F5DFF', 'shop', true, 1),
  ('Vacinação em domicílio', 'Agende agora e ganhe 10% de desconto', 'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=800', '#00C2A8', 'booking', true, 2),
  ('Ração Premium com Frete Grátis', 'Em compras acima de R$ 150', 'https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=800', '#FF6B6B', 'shop', true, 3);

END $$;
