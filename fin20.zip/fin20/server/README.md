# PetsGo Backend API

## 🚀 API REST completa para o aplicativo PetsGo

### Estrutura da API

```
server/
├── database/
│   ├── db.js           # Configuração do PostgreSQL
│   ├── schema.sql      # Schema completo do banco
│   └── seed.sql        # Dados iniciais
├── routes/
│   ├── auth.js         # Autenticação (login, signup, forgot-password)
│   ├── stores.js       # Lojas e Pet Shops
│   ├── products.js     # Produtos
│   ├── services.js     # Serviços (banho, tosa, etc)
│   ├── cart.js         # Carrinho de compras
│   ├── orders.js       # Pedidos
│   ├── favorites.js    # Favoritos
│   ├── addresses.js    # Endereços
│   ├── paymentMethods.js # Métodos de pagamento
│   ├── notifications.js  # Notificações
│   ├── reviews.js      # Avaliações
│   ├── bookings.js     # Agendamentos
│   ├── coupons.js      # Cupons de desconto
│   └── profile.js      # Perfil do usuário e pets
├── middleware/
│   └── auth.js         # Middleware de autenticação JWT
├── utils/
│   ├── password.js     # Utilitários de senha
│   └── calculateDistance.js # Cálculo de distância
└── index.js            # Servidor Express principal
```

### Endpoints Disponíveis

#### Autenticação
- `POST /api/auth/signup` - Criar conta
- `POST /api/auth/login` - Fazer login
- `POST /api/auth/forgot-password` - Recuperar senha

#### Lojas
- `GET /api/stores` - Listar lojas (com filtros)
- `GET /api/stores/:id` - Detalhes da loja

#### Produtos
- `GET /api/products` - Listar produtos
- `GET /api/products/:id` - Detalhes do produto

#### Serviços
- `GET /api/services` - Listar serviços
- `GET /api/services/:id` - Detalhes do serviço

#### Carrinho (requer autenticação)
- `GET /api/cart` - Ver carrinho
- `POST /api/cart/items` - Adicionar ao carrinho
- `PATCH /api/cart/items/:id` - Atualizar quantidade
- `DELETE /api/cart/items/:id` - Remover item
- `DELETE /api/cart` - Esvaziar carrinho

#### Pedidos (requer autenticação)
- `GET /api/orders` - Listar pedidos
- `GET /api/orders/:id` - Detalhes do pedido
- `POST /api/orders` - Criar pedido

#### Favoritos (requer autenticação)
- `GET /api/favorites` - Listar favoritos
- `POST /api/favorites` - Adicionar favorito
- `DELETE /api/favorites/:storeId` - Remover favorito

#### Endereços (requer autenticação)
- `GET /api/addresses` - Listar endereços
- `POST /api/addresses` - Adicionar endereço
- `PATCH /api/addresses/:id` - Atualizar endereço
- `DELETE /api/addresses/:id` - Remover endereço

#### Métodos de Pagamento (requer autenticação)
- `GET /api/payment-methods` - Listar métodos
- `POST /api/payment-methods` - Adicionar método
- `DELETE /api/payment-methods/:id` - Remover método

#### Notificações (requer autenticação)
- `GET /api/notifications` - Listar notificações
- `PATCH /api/notifications/:id/read` - Marcar como lida
- `PATCH /api/notifications/read-all` - Marcar todas como lidas
- `GET /api/notifications/settings` - Ver configurações
- `PATCH /api/notifications/settings` - Atualizar configurações

#### Avaliações
- `GET /api/reviews?store_id=:id` - Listar reviews
- `POST /api/reviews` - Criar review (requer autenticação)

#### Agendamentos (requer autenticação)
- `GET /api/bookings` - Listar agendamentos
- `POST /api/bookings` - Criar agendamento
- `PATCH /api/bookings/:id` - Atualizar status

#### Cupons (requer autenticação)
- `POST /api/coupons/validate` - Validar cupom

#### Perfil (requer autenticação)
- `GET /api/profile` - Ver perfil
- `PATCH /api/profile` - Atualizar perfil
- `GET /api/profile/pets` - Listar pets
- `POST /api/profile/pets` - Adicionar pet
- `PATCH /api/profile/pets/:id` - Atualizar pet
- `DELETE /api/profile/pets/:id` - Remover pet

### Como Iniciar

1. Configure as variáveis de ambiente no `.env`
2. Execute o schema do banco: `psql $DATABASE_URL < server/database/schema.sql`
3. Popule com dados iniciais: `psql $DATABASE_URL < server/database/seed.sql`
4. Inicie o servidor: `npm run server` ou `npm run server:dev`

### Autenticação

A API usa JWT (JSON Web Tokens) para autenticação. Para endpoints protegidos, inclua o token no header:

```
Authorization: Bearer <seu-token-jwt>
```

### Banco de Dados

O schema inclui as seguintes tabelas principais:
- `users` - Usuários
- `user_pets` - Pets dos usuários
- `stores` - Lojas e Pet Shops
- `products` - Produtos
- `services` - Serviços
- `cart_items` - Itens do carrinho
- `orders` - Pedidos
- `order_items` - Itens dos pedidos
- `order_tracking` - Rastreamento de pedidos
- `favorites` - Favoritos
- `addresses` - Endereços
- `payment_methods` - Métodos de pagamento
- `reviews` - Avaliações
- `bookings` - Agendamentos
- `notifications` - Notificações
- `notification_settings` - Configurações de notificação
- `coupons` - Cupons de desconto
- `banners` - Banners promocionais

Todas as tabelas incluem timestamps automáticos e relacionamentos apropriados.
