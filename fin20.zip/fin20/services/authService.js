import AsyncStorage from '@react-native-async-storage/async-storage';
import { authAPI, api } from './api';

const TOKEN_KEY = '@petsgo_auth_token';
const USER_KEY = '@petsgo_user';

class AuthService {
  constructor() {
    this.token = null;
    this.user = null;
  }

  async login(email, password) {
    try {
      console.log('🔐 Tentando fazer login com:', email);
      const response = await authAPI.login({ email, password });
      console.log('✅ Resposta do servidor:', response);
      
      if (response.token && response.user) {
        this.token = response.token;
        this.user = response.user;
        
        api.setAuthToken(response.token);
        
        await AsyncStorage.setItem(TOKEN_KEY, response.token);
        await AsyncStorage.setItem(USER_KEY, JSON.stringify(response.user));
        
        console.log('✅ Login bem-sucedido!', response.user.name);
        return { success: true, user: response.user };
      }
      
      console.error('❌ Resposta sem token ou user');
      return { success: false, error: 'Resposta inválida do servidor' };
    } catch (error) {
      console.error('❌ Erro no login:', error);
      console.error('❌ Detalhes do erro:', error.message, error.stack);
      return { 
        success: false, 
        error: error.message || 'Erro ao fazer login' 
      };
    }
  }

  async signup(userData) {
    try {
      console.log('📝 Tentando criar conta:', userData.email);
      const response = await authAPI.signup(userData);
      console.log('✅ Resposta do servidor (signup):', response);
      
      if (response.token && response.user) {
        this.token = response.token;
        this.user = response.user;
        
        api.setAuthToken(response.token);
        
        await AsyncStorage.setItem(TOKEN_KEY, response.token);
        await AsyncStorage.setItem(USER_KEY, JSON.stringify(response.user));
        
        console.log('✅ Conta criada com sucesso!', response.user.name);
        return { success: true, user: response.user };
      }
      
      console.error('❌ Resposta sem token ou user (signup)');
      return { success: false, error: 'Resposta inválida do servidor' };
    } catch (error) {
      console.error('❌ Erro ao criar conta:', error);
      console.error('❌ Detalhes do erro:', error.message, error.stack);
      return { 
        success: false, 
        error: error.message || 'Erro ao criar conta' 
      };
    }
  }

  async logout() {
    this.token = null;
    this.user = null;
    api.setAuthToken(null);
    
    await AsyncStorage.removeItem(TOKEN_KEY);
    await AsyncStorage.removeItem(USER_KEY);
  }

  async loadStoredAuth() {
    try {
      const token = await AsyncStorage.getItem(TOKEN_KEY);
      const userStr = await AsyncStorage.getItem(USER_KEY);
      
      if (token && userStr) {
        this.token = token;
        this.user = JSON.parse(userStr);
        api.setAuthToken(token);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error loading stored auth:', error);
      return false;
    }
  }

  getUser() {
    return this.user;
  }

  getToken() {
    return this.token;
  }

  isAuthenticated() {
    return !!this.token;
  }
}

export const authService = new AuthService();
export default authService;
