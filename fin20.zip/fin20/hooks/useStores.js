import { useState, useEffect } from 'react';
import { storeAPI } from '../services/api';

export function useStores(params = {}) {
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchStores() {
      try {
        setLoading(true);
        const data = await storeAPI.getAll(params);
        setStores(data.stores || data || []);
        setError(null);
      } catch (err) {
        console.error('Error fetching stores:', err);
        setError(err.message);
        setStores([]);
      } finally {
        setLoading(false);
      }
    }

    fetchStores();
  }, [JSON.stringify(params)]);

  return { stores, loading, error };
}

export function useStore(id) {
  const [store, setStore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!id) {
      setLoading(false);
      return;
    }

    async function fetchStore() {
      try {
        setLoading(true);
        const data = await storeAPI.getById(id);
        setStore(data.store || data);
        setError(null);
      } catch (err) {
        console.error('Error fetching store:', err);
        setError(err.message);
        setStore(null);
      } finally {
        setLoading(false);
      }
    }

    fetchStore();
  }, [id]);

  return { store, loading, error };
}
