# PetsGo - Pet Services & E-commerce Platform

## Overview

PetsGo é uma aplicação mobile-first completa construída com React Native e Expo que conecta donos de pets com pet shops, serviços e produtos. A plataforma oferece e-commerce, agendamento de serviços, rastreamento de pedidos em tempo real e sistema de fidelidade.

**Status**: ✅ Totalmente funcional - Backend conectado ao Frontend com banco de dados PostgreSQL real

## User Preferences

Comunicação preferida: Linguagem simples e cotidiana em português

## Arquitetura do Sistema

### Stack Completo

**Frontend**
- React Native v0.81.5 + React 19
- Expo SDK ~54 para desenvolvimento cross-platform
- File-based routing com Expo Router v6
- Gestão de estado local com hooks
- AsyncStorage para persistência de dados
- Animações com react-native-reanimated v4

**Backend**
- Node.js com Express.js
- Porta 3001 (API REST)
- JWT para autenticação
- bcryptjs para hashing de senhas
- express-validator para validação

**Banco de Dados**
- PostgreSQL (Replit-managed)
- Schema completo com relacionamentos
- Dados seed incluídos

### Configuração do Ambiente

**Variáveis de Ambiente (Replit Secrets)**
- `JWT_SECRET`: Chave secreta para tokens JWT
- `DATABASE_URL`: URL de conexão PostgreSQL
- `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, `PGDATABASE`: Configurações individuais do PostgreSQL

**Workflows Configurados**
- `backend`: `npm run server:dev` (porta 3001, console)
- `frontend`: `npm run web` (porta 5000, webview)

### Arquitetura da Aplicação

**Autenticação Real**
- Login/Signup conectados à API
- AuthService (`services/authService.js`) gerencia tokens
- Token JWT persistido com AsyncStorage
- Sessões mantidas entre reinicializações

**Conexão Frontend-Backend**
- Webpack proxy configurado: `/api/*` → `http://localhost:3001`
- API base URL dinâmica para web e native
- Hooks customizados: `useStores`, `useProducts`
- Sem dados mock - tudo vem do banco de dados

**Fluxo de Dados**
```
Frontend (5000) → Webpack Proxy → Backend (3001) → PostgreSQL
```

### Banco de Dados

**Tabelas Principais**
- `users` - Usuários com autenticação
- `stores` - Lojas e Pet Shops
- `products` - Produtos disponíveis
- `services` - Serviços (banho, tosa, veterinário)
- `orders` - Pedidos com rastreamento
- `cart_items` - Carrinho de compras
- `favorites` - Favoritos dos usuários
- `addresses` - Endereços de entrega
- `payment_methods` - Métodos de pagamento
- `notifications` - Sistema de notificações

**Scripts de Banco de Dados**
- `server/database/schema.sql` - Schema completo
- `server/database/seed.sql` - Dados iniciais
- `server/database/db.js` - Cliente PostgreSQL

### API Endpoints

**Autenticação** (`/api/auth`)
- POST `/login` - Login de usuário
- POST `/signup` - Criar nova conta
- POST `/forgot-password` - Recuperação de senha

**Lojas** (`/api/stores`)
- GET `/` - Listar todas as lojas
- GET `/:id` - Detalhes da loja

**Produtos** (`/api/products`)
- GET `/` - Listar produtos
- GET `/:id` - Detalhes do produto

**Outros Endpoints**
- `/api/cart` - Gerenciamento do carrinho
- `/api/orders` - Pedidos
- `/api/favorites` - Favoritos
- `/api/profile` - Perfil do usuário
- `/api/services` - Serviços disponíveis

### Usuário de Teste

Para testar a aplicação:
- **Email**: teste@petsgo.com
- **Senha**: 123456

## Mudanças Recentes (11/11/2025)

### Setup Completo do Ambiente Replit - CONCLUÍDO ✅

✅ **Configuração Inicial**
- Projeto extraído e organizado na raiz do workspace
- Node.js 20 instalado e configurado
- Todas as dependências npm instaladas com `--legacy-peer-deps`
- Arquivos duplicados removidos (fin18/, fin16/)

✅ **Banco de Dados PostgreSQL**
- PostgreSQL provisionado e conectado
- Extensões instaladas: uuid-ossp, cube, earthdistance
- Schema completo aplicado (20 tabelas + índices + triggers)
- Dados seed inseridos com sucesso:
  - 5 lojas de exemplo
  - Produtos e serviços
  - 3 cupons de desconto
  - 3 banners promocionais
- Usuário de teste criado e funcionando

✅ **Backend API**
- Servidor Express rodando estável na porta 3001
- Todas as rotas REST configuradas
- JWT_SECRET configurado para autenticação
- Conexão com PostgreSQL funcionando 100%
- Health check endpoint testado e funcionando
- API endpoints testados (stores, products, etc)

✅ **Frontend Web**
- Expo/React Native Web rodando na porta 5000
- Webpack configurado com:
  - `allowedHosts: 'all'` (crítico para Replit proxy)
  - Proxy `/api/*` → `http://localhost:3001`
- Metro bundler compilado com sucesso (1320 módulos)
- Interface web acessível e funcional

✅ **Workflows Configurados**
- `backend`: npm run server:dev (porta 3001, console)
- `frontend`: npm run web (porta 5000, webview)
- Ambos rodando sem erros

✅ **Integração Frontend-Backend**
- Proxy configurado corretamente
- API respondendo às requisições do frontend
- Autenticação JWT pronta para uso
- Fluxo de dados completo: Frontend → Proxy → Backend → PostgreSQL

## Próximos Passos Sugeridos

1. **Deploy/Publicação**: Configurar para produção usando a ferramenta de deploy do Replit
2. **Mais Features**: 
   - Implementar carrinho de compras completo
   - Sistema de pedidos e tracking
   - Perfil de usuário e pets
3. **Melhorias**: 
   - Adicionar loading states
   - Error handling mais robusto
   - Testes automatizados

## Notas Técnicas

- Apenas a porta 5000 é exposta publicamente no Replit
- Backend não é acessível externamente (apenas via proxy interno)
- Para testes nativos (iOS/Android), ajustar API_BASE_URL conforme necessário
- AsyncStorage funciona tanto web quanto mobile
